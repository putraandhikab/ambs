<?php

class Todolist extends MY_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('todo_model');
    }

    public function index() {
        // get data from the model
        $items = $this->todo_model->get_all();

        $this->data['items'] = $items;

        // pass the data to the view

        $this->load->view('todolist', $this->data);
    }

    public function set_item() {
        // get value from the post
        $item = $this->input->post('item');

        $insert = array();
        $insert['desc'] = $item;
        // insert them into the the database
        $id = $this->todo_model->insert($insert);

        if($id) {
            $items = $this->todo_model->get_all();
            $this->data['items'] = $items;
            $this->load->view('todolist', $this->data);
        }else {
            echo "did not record values";
        }
    }

    public function delete($id) {
        $this->todo_model->where('id', $id)->delete();
        $this->index();
    }
}